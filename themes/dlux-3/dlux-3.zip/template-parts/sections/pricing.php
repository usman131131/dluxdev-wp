<?php
if ( ! defined( 'ABSPATH' ) ) exit;
$sizes = array_values( array_filter( (array) get_sub_field( 'vehicle_sizes' ), function ( $s ) {
	return ! empty( $s['label'] ) || ! empty( $s['packages'] );
} ) );
$uid   = 'pricing-' . get_row_index();
?>
<section class="section section--surface pricing"<?php echo dlux_section_id( get_sub_field( 'section_id' ) ); // phpcs:ignore ?> data-pricing>
	<div class="container">
		<div class="section-head section-head--split">
			<div><?php echo dlux_section_head( get_sub_field( 'eyebrow' ), get_sub_field( 'heading' ) ); // phpcs:ignore ?></div>

			<?php if ( count( $sizes ) > 1 ) : ?>
				<div class="size-switch" role="tablist" aria-label="<?php esc_attr_e( 'Vehicle size', 'dlux' ); ?>">
					<?php foreach ( $sizes as $i => $size ) : ?>
						<button type="button" role="tab" class="size-switch__btn"
							id="<?php echo esc_attr( "{$uid}-tab-{$i}" ); ?>"
							aria-controls="<?php echo esc_attr( "{$uid}-panel-{$i}" ); ?>"
							aria-selected="<?php echo 0 === $i ? 'true' : 'false'; ?>">
							<?php echo esc_html( $size['label'] ); ?>
						</button>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>

		<?php foreach ( $sizes as $i => $size ) :
			$packages = $size['packages'] ?: [];
			$multi    = count( $sizes ) > 1;
			?>
			<div class="pricing__grid" id="<?php echo esc_attr( "{$uid}-panel-{$i}" ); ?>"
				<?php if ( $multi ) : ?>role="tabpanel" aria-labelledby="<?php echo esc_attr( "{$uid}-tab-{$i}" ); ?>"<?php endif; ?>
				<?php echo 0 === $i ? '' : 'hidden'; ?>>
				<?php foreach ( $packages as $p ) :
					$featured = ! empty( $p['is_featured'] );
					$features = array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', (string) $p['features'] ) ) );
					$price    = $p['price'];
					?>
					<article class="package<?php echo $featured ? ' is-featured' : ''; ?>">
						<?php if ( $featured && ! empty( $p['badge'] ) ) : ?>
							<span class="package__badge"><?php echo esc_html( $p['badge'] ); ?></span>
						<?php endif; ?>
						<h3 class="package__name"><?php echo esc_html( $p['name'] ); ?></h3>
						<?php if ( ! empty( $p['subtitle'] ) ) : ?>
							<p class="package__sub"><?php echo esc_html( $p['subtitle'] ); ?></p>
						<?php endif; ?>

						<p class="package__price">
							<?php if ( '' !== $price && null !== $price ) : ?>
								<span class="price__currency">$</span><?php echo esc_html( rtrim( rtrim( number_format( (float) $price, 2, '.', '' ), '0' ), '.' ) ); ?>
							<?php else : ?>
								<span class="price__poa"><?php esc_html_e( 'POA', 'dlux' ); ?></span>
							<?php endif; ?>
						</p>

						<?php if ( $features ) : ?>
							<ul class="package__features">
								<?php foreach ( $features as $f ) : ?>
									<li><?php echo esc_html( $f ); ?></li>
								<?php endforeach; ?>
							</ul>
						<?php endif; ?>

						<div class="package__cta">
							<?php echo dlux_button( $p['button'], $featured ? 'btn--primary btn--xs' : 'btn--outline btn--xs' ); // phpcs:ignore ?>
						</div>
					</article>
				<?php endforeach; ?>
			</div>
		<?php endforeach; ?>

		<?php if ( $note = get_sub_field( 'footnote' ) ) : ?>
			<p class="pricing__note"><?php echo wp_kses( $note, [ 'br' => [], 'a' => [ 'href' => [] ] ] ); ?></p>
		<?php endif; ?>
	</div>
</section>
