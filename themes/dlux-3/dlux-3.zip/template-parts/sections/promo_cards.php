<?php
if ( ! defined( 'ABSPATH' ) ) exit;
$cards = get_sub_field( 'cards' );
if ( ! $cards ) return;
?>
<section class="section promos"<?php echo dlux_section_id( get_sub_field( 'section_id' ) ); // phpcs:ignore ?>>
	<div class="container promos__grid">
		<?php foreach ( $cards as $c ) :
			$style   = 'dark' === $c['style'] ? 'dark' : 'accent';
			$btn_cls = 'accent' === $style ? 'btn--light btn--sm' : 'btn--primary btn--sm';
			$top     = 'top' === $c['button_position'];
			$id      = ! empty( $c['label'] ) ? ' id="' . esc_attr( sanitize_title( $c['label'] ) ) . '"' : '';
			?>
			<article class="promo promo--<?php echo esc_attr( $style ); ?><?php echo ! empty( $c['image']['ID'] ) ? ' has-image' : ''; ?>"<?php echo $id; // phpcs:ignore ?>>
				<div class="promo__top">
					<?php if ( ! empty( $c['label'] ) ) : ?><p class="promo__label"><?php echo esc_html( $c['label'] ); ?></p><?php endif; ?>
					<?php if ( $top ) echo dlux_button( $c['button'], $btn_cls ); // phpcs:ignore ?>
				</div>
				<h2 class="promo__title"><?php echo dlux_heading( $c['heading'] ); // phpcs:ignore ?></h2>
				<?php if ( ! empty( $c['text'] ) ) : ?>
					<p class="promo__text"><?php echo wp_kses( $c['text'], [ 'br' => [] ] ); ?></p>
				<?php endif; ?>
				<?php if ( ! $top ) echo dlux_button( $c['button'], $btn_cls ); // phpcs:ignore ?>
				<?php if ( ! empty( $c['image']['ID'] ) ) echo wp_get_attachment_image( $c['image']['ID'], 'large', false, [ 'class' => 'promo__img', 'alt' => '', 'loading' => 'lazy' ] ); ?>
			</article>
		<?php endforeach; ?>
	</div>
</section>
