<?php
if ( ! defined( 'ABSPATH' ) ) exit;
$cards = get_sub_field( 'cards' );
?>
<section class="section section--surface services"<?php echo dlux_section_id( get_sub_field( 'section_id' ) ); // phpcs:ignore ?>>
	<div class="container">
		<div class="section-head">
			<?php echo dlux_section_head( get_sub_field( 'eyebrow' ), get_sub_field( 'heading' ) ); // phpcs:ignore ?>
			<?php if ( $intro = get_sub_field( 'intro' ) ) : ?>
				<p class="section-intro"><?php echo wp_kses( $intro, [ 'br' => [] ] ); ?></p>
			<?php endif; ?>
		</div>

		<?php if ( $cards ) : ?>
			<div class="cards">
				<?php foreach ( $cards as $c ) :
					$has_link = ! empty( $c['link']['url'] );
					$tag      = $has_link ? 'a' : 'div';
					$attrs    = $has_link ? ' href="' . esc_url( $c['link']['url'] ) . '"' . ( ! empty( $c['link']['target'] ) ? ' target="' . esc_attr( $c['link']['target'] ) . '"' : '' ) : '';
					?>
					<<?php echo $tag . $attrs; // phpcs:ignore ?> class="card">
						<div class="card__media">
							<?php if ( ! empty( $c['image']['ID'] ) ) echo wp_get_attachment_image( $c['image']['ID'], 'dlux-card', false, [ 'alt' => '', 'loading' => 'lazy' ] ); ?>
						</div>
						<div class="card__body">
							<h3 class="card__title"><?php echo esc_html( $c['title'] ); ?></h3>
							<?php if ( ! empty( $c['text'] ) ) : ?>
								<p class="card__text"><?php echo wp_kses( $c['text'], [ 'br' => [] ] ); ?></p>
							<?php endif; ?>
						</div>
					</<?php echo $tag; // phpcs:ignore ?>>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
	</div>
</section>
