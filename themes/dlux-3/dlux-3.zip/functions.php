<?php
/**
 * DLUX theme functions.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

define( 'DLUX_VERSION', '1.2.2' );
define( 'DLUX_DIR', get_template_directory() );
define( 'DLUX_URI', get_template_directory_uri() );

require DLUX_DIR . '/inc/helpers.php';
require DLUX_DIR . '/inc/icons.php';

/* ---------- Theme setup ---------- */
add_action( 'after_setup_theme', function () {
	load_theme_textdomain( 'dlux', DLUX_DIR . '/languages' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', [ 'search-form', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' ] );
	add_theme_support( 'responsive-embeds' );
	register_nav_menus( [
		'primary' => __( 'Primary Menu', 'dlux' ),
		'footer'  => __( 'Footer Menu', 'dlux' ),
	] );
	add_image_size( 'dlux-card', 760, 420, true );
	add_image_size( 'dlux-thumb', 120, 120, true );
} );

/* ---------- Assets ---------- */
add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style( 'dlux-main', DLUX_URI . '/assets/css/main.css', [], DLUX_VERSION );
	wp_add_inline_style( 'dlux-main', dlux_css_variables() );
	wp_enqueue_script( 'dlux-main', DLUX_URI . '/assets/js/main.js', [], DLUX_VERSION, [ 'strategy' => 'defer', 'in_footer' => true ] );
} );

/* Preload the two most-used local fonts (heading + paragraph) */
add_action( 'wp_head', function () {
	foreach ( [ 'nokia-expanded/NokiaExpanded-Black.woff2', 'sequel-sans/SequelSansBody-Roman.woff2' ] as $font ) {
		printf( '<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n", esc_url( DLUX_URI . '/assets/fonts/' . $font ) );
	}
}, 2 );

/* Colour overrides from Theme Settings */
function dlux_css_variables() {
	$map = [
		'--accent'  => dlux_option( 'accent_color' ),
		'--bg'      => dlux_option( 'background_color' ),
		'--surface' => dlux_option( 'surface_color' ),
	];
	$css = '';
	foreach ( $map as $var => $val ) {
		if ( $val && preg_match( '/^#[0-9a-fA-F]{3,8}$/', $val ) ) {
			$css .= $var . ':' . $val . ';';
		}
	}
	return $css ? ':root{' . $css . '}' : '';
}

/* ---------- Site icon from Theme Settings ---------- */
add_action( 'wp_head', function () {
	if ( has_site_icon() ) return;
	$icon = dlux_option( 'site_icon' );
	if ( ! empty( $icon['url'] ) ) {
		printf( '<link rel="icon" href="%s">' . "\n", esc_url( $icon['url'] ) );
	}
}, 5 );

/* ---------- Custom scripts (admin controlled) ---------- */
add_action( 'wp_head', function () {
	$s = dlux_option( 'head_scripts' );
	if ( $s ) echo $s . "\n"; // phpcs:ignore -- entered by administrators.
}, 99 );
add_action( 'wp_footer', function () {
	$s = dlux_option( 'footer_scripts' );
	if ( $s ) echo $s . "\n"; // phpcs:ignore
}, 99 );

/* ---------- Options page fallback ----------
 * If the "Theme Settings" options page was not imported via JSON,
 * register it in code so the field group still has a home. */
add_action( 'acf/init', function () {
	if ( ! function_exists( 'acf_add_options_page' ) ) return;
	if ( function_exists( 'acf_get_options_page' ) && acf_get_options_page( 'theme-settings' ) ) return;
	acf_add_options_page( [
		'page_title' => __( 'Theme Settings', 'dlux' ),
		'menu_title' => __( 'Theme Settings', 'dlux' ),
		'menu_slug'  => 'theme-settings',
		'capability' => 'edit_theme_options',
		'icon_url'   => 'dashicons-admin-customizer',
		'position'   => 59,
	] );
}, 99 );

/* ---------- Menus shortcut under Theme Settings ----------
 * Header/footer menus are managed in Appearance > Menus; this adds a
 * "Menus" link inside the Theme Settings admin menu as well. */
add_action( 'admin_menu', function () {
	global $admin_page_hooks;
	if ( empty( $admin_page_hooks['theme-settings'] ) ) return;
	add_submenu_page( 'theme-settings', __( 'Settings', 'dlux' ), __( 'Settings', 'dlux' ), 'edit_theme_options', 'theme-settings' );
	add_submenu_page( 'theme-settings', __( 'Menus', 'dlux' ), __( 'Header & Footer Menus', 'dlux' ), 'edit_theme_options', 'nav-menus.php' );
}, 999 );

/* ---------- Notice if SCF/ACF is missing ---------- */
add_action( 'admin_notices', function () {
	if ( function_exists( 'get_field' ) ) return;
	echo '<div class="notice notice-warning"><p><strong>DLUX theme:</strong> ' .
		esc_html__( 'Install and activate Secure Custom Fields (or ACF Pro) to use page sections and Theme Settings.', 'dlux' ) .
		'</p></div>';
} );

/* Body classes */
add_filter( 'body_class', function ( $classes ) {
	if ( dlux_option( 'sticky_header', true ) ) $classes[] = 'has-sticky-header';
	if ( is_page() && dlux_page_starts_with_hero() && dlux_option( 'transparent_header', true ) ) {
		$classes[] = 'has-transparent-header';
	}
	return $classes;
} );
