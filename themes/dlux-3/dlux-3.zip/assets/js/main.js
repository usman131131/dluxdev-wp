(function () {
	'use strict';

	/* Header: scrolled state */
	var header = document.querySelector('[data-header]');
	if (header) {
		var onScroll = function () { header.classList.toggle('is-scrolled', window.scrollY > 10); };
		onScroll();
		window.addEventListener('scroll', onScroll, { passive: true });
	}

	/* Mobile navigation */
	var toggle = document.querySelector('[data-nav-toggle]');
	var nav = document.querySelector('[data-nav]');
	if (toggle && nav) {
		var setOpen = function (open) {
			toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
			nav.classList.toggle('is-open', open);
			document.body.classList.toggle('nav-open', open);
		};
		toggle.addEventListener('click', function () {
			setOpen(toggle.getAttribute('aria-expanded') !== 'true');
		});
		nav.addEventListener('click', function (e) {
			if (e.target.closest('a')) setOpen(false);
		});
		document.addEventListener('keydown', function (e) {
			if (e.key === 'Escape' && nav.classList.contains('is-open')) { setOpen(false); toggle.focus(); }
		});
		window.addEventListener('resize', function () {
			if (window.innerWidth > 1024) setOpen(false);
		});
	}

	/* Pricing: vehicle size switcher (tabs -> panels) */
	document.querySelectorAll('[data-pricing]').forEach(function (section) {
		var buttons = Array.prototype.slice.call(section.querySelectorAll('.size-switch__btn'));
		var select = function (btn) {
			buttons.forEach(function (b) {
				var on = b === btn;
				b.setAttribute('aria-selected', on ? 'true' : 'false');
				b.tabIndex = on ? 0 : -1;
				var panel = document.getElementById(b.getAttribute('aria-controls'));
				if (panel) {
					panel.hidden = !on;
					if (on) panel.scrollLeft = 0;
				}
			});
		};
		buttons.forEach(function (btn, i) {
			btn.tabIndex = btn.getAttribute('aria-selected') === 'true' ? 0 : -1;
			btn.addEventListener('click', function () { select(btn); });
			btn.addEventListener('keydown', function (e) {
				var dir = e.key === 'ArrowRight' ? 1 : e.key === 'ArrowLeft' ? -1 : 0;
				if (!dir) return;
				e.preventDefault();
				var next = buttons[(i + dir + buttons.length) % buttons.length];
				select(next);
				next.focus();
			});
		});
	});
})();
